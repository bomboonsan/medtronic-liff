<x-app-layout>
    
    <x-dashboard.layout>
        Dashboard
    </x-dashboard.layout>

</x-app-layout>
