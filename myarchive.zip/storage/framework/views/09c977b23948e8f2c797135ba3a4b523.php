<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php if (isset($component)) { $__componentOriginalb998c89882eab8e1df2af93927d4d429 = $component; } ?>
<?php $component = App\View\Components\Dashboard\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="">
            <div class="flex flex-wrap gap-5">
                <div class="basis-[20%] w-[20%]">
                    <div class="dashboard-card">
                        <h2 class="title mb-5">เพิ่มตำแหน่งงาน</h2>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                
                        <form action="<?php echo e(route('specialties.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="flex gap-2">
                                <input type="text" class="input input-bordered input-sm w-full max-w-xs" id="name" name="name" placeholder="ชื่อตำแหน่งงาน" required />
                                <button type="submit" class="btn btn-sm btn-primary">เพิ่ม</button>
                            </div>
                        </form>
                        <div class="form-text">
                            <p>
                                เพิ่มตำแหน่งงานได้ง่ายๆ โดยเพียงกรอกชื่อหมวดหมู่ที่ต้องการในช่องที่กำหนด และกดปุ่ม 'เพิ่ม' เพื่อบันทึกการเปลี่ยนแปลงของคุณ!
                            </p>
                        </div>
                    </div>
                </div>
                <div class="flex-1">
                    <div class="dashboard-card">
                        <h2 class="title mb-5">รายชื่อตำแหน่งงาน</h2>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                
                        <table class="table">
                            <col style="width:30px">
                            <col style="width:auto">
                            <col style="width:20%">
                            <thead>
                                <tr>
                                    <th>ลำดับ</th>
                                    <th>ชื่อตำแหน่ง</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $specialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        
                                        <td><?php echo e($index + 1); ?></td>
                                        <td>
                                            <a class="table-link" href="<?php echo e(route('specialties-show', $specialty->id)); ?>"><?php echo e($specialty->name); ?></a>                                            
                                        </td>
                                        <td>
                                            
                                            <button class="btn btn-warning btn-sm" onclick="edit_modal_<?php echo e($specialty->id); ?>.showModal()">
                                                <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h357l-80 80H200v560h560v-278l80-80v358q0 33-23.5 56.5T760-120H200Zm280-360ZM360-360v-170l367-367q12-12 27-18t30-6q16 0 30.5 6t26.5 18l56 57q11 12 17 26.5t6 29.5q0 15-5.5 29.5T897-728L530-360H360Zm481-424-56-56 56 56ZM440-440h56l232-232-28-28-29-28-231 231v57Zm260-260-29-28 29 28 28 28-28-28Z"/></svg>
                                                
                                            </button>
                                            <dialog id="edit_modal_<?php echo e($specialty->id); ?>" class="modal">
                                                <div class="modal-box">
                                                    <h3 class="font-bold text-lg mb-4">แก้ไข <?php echo e($specialty->name); ?></h3>
                                                    <form action="<?php echo e(route('specialties.update', $specialty->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?> 
                                                        <div class="flex gap-3 items-center">
                                                            <div class="flex-1">
                                                                <input type="text" class="input input-bordered input-sm w-full" name="name" value="<?php echo e($specialty->name); ?>" required>
                                                            </div>
                                                            <button type="submit" class="btn btn-primary btn-sm">บันทึก</button>
                                                        </div>
                                                    </form>
                                                </div>
                                                <form method="dialog" class="modal-backdrop">
                                                <button>close</button>
                                                </form>
                                            </dialog>
                                            <form action="<?php echo e(route('specialties.destroy', $specialty->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-error btn-sm" onclick="return confirm('Are you sure?')">
                                                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="m376-300 104-104 104 104 56-56-104-104 104-104-56-56-104 104-104-104-56 56 104 104-104 104 56 56Zm-96 180q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520Zm-400 0v520-520Z"/></svg>   
                                                    
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3">No specialty found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb998c89882eab8e1df2af93927d4d429)): ?>
<?php $component = $__componentOriginalb998c89882eab8e1df2af93927d4d429; ?>
<?php unset($__componentOriginalb998c89882eab8e1df2af93927d4d429); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/bomboonsan/Desktop/laravel/medtronicLineLiff/resources/views/dashboard/specialties/index.blade.php ENDPATH**/ ?>