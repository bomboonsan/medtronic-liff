<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-register">
        <?php if(!empty($userRegister)): ?>
            <?php if($userRegister->status == 'approved'): ?>
            <h1>
                <?php echo e($userRegister->first_name); ?> <?php echo e($userRegister->last_name); ?>

            </h1>
            <p><?php echo e($userRegister->status); ?></p>
            <?php endif; ?>
            <?php if($userRegister->status == 'pending'): ?>
                <h1>
                    <?php echo e($userRegister->first_name); ?> <?php echo e($userRegister->last_name); ?>

                </h1>
                <p><?php echo e($userRegister->status); ?></p>
            <?php endif; ?>
            <?php if($userRegister->status == 'disapproved'): ?>
                <h1>
                    <?php echo e($userRegister->first_name); ?> <?php echo e($userRegister->last_name); ?>

                </h1>
                <p><?php echo e($userRegister->status); ?></p>
            <?php endif; ?>
        <?php else: ?>
            <h1>
                GO TO Register
            </h1>
        <?php endif; ?>        
    </div>    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH /home/bomboonsan/Desktop/laravel/medtronicLineLiff/resources/views/checkToken.blade.php ENDPATH**/ ?>