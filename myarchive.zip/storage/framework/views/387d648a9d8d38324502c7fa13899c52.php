<div>
    <div class="flex flex-wrap items-stretch min-h-screen">
        <div class="basis-[200px] w-[200px] bg-white">
            <?php if (isset($component)) { $__componentOriginalc93999cea703a57ef48c6aa2fd7a5d47 = $component; } ?>
<?php $component = App\View\Components\Dashboard\Menu::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc93999cea703a57ef48c6aa2fd7a5d47)): ?>
<?php $component = $__componentOriginalc93999cea703a57ef48c6aa2fd7a5d47; ?>
<?php unset($__componentOriginalc93999cea703a57ef48c6aa2fd7a5d47); ?>
<?php endif; ?>
        </div>
        <div class="flex-1 p-7">
            <?php echo e($slot); ?>

        </div>
    </div>
</div><?php /**PATH /home/bomboonsan/Desktop/laravel/medtronicLineLiff/resources/views/components/dashboard/layout.blade.php ENDPATH**/ ?>